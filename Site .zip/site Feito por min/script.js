// Instituto do Lago - Premium Interactive Scripts

document.addEventListener('DOMContentLoaded', () => {

    // === Loading Screen ===
    const loader = document.getElementById('loader');
    window.addEventListener('load', () => {
        setTimeout(() => {
            loader.classList.add('hidden');
            document.body.style.overflow = '';
            initHeroAnimations();
        }, 1400);
    });
    // Fallback
    setTimeout(() => {
        loader.classList.add('hidden');
        initHeroAnimations();
    }, 3000);

    // === Custom Cursor ===
    const cursor = document.getElementById('cursor');
    const follower = document.getElementById('cursorFollower');
    let mouseX = 0, mouseY = 0;
    let followerX = 0, followerY = 0;

    if (window.innerWidth > 768) {
        document.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
            cursor.style.left = mouseX + 'px';
            cursor.style.top = mouseY + 'px';
        });

        function animateFollower() {
            followerX += (mouseX - followerX) * 0.12;
            followerY += (mouseY - followerY) * 0.12;
            follower.style.left = followerX + 'px';
            follower.style.top = followerY + 'px';
            requestAnimationFrame(animateFollower);
        }
        animateFollower();

        // Hover effects for links and buttons
        const hoverTargets = document.querySelectorAll('a, button, .btn, .service-card, .team-card, .about-card, .magnetic');
        hoverTargets.forEach(el => {
            el.addEventListener('mouseenter', () => {
                cursor.classList.add('hover');
                follower.classList.add('hover');
            });
            el.addEventListener('mouseleave', () => {
                cursor.classList.remove('hover');
                follower.classList.remove('hover');
            });
        });
    }

    // === Progress Bar ===
    const progressBar = document.getElementById('progressBar');
    function updateProgress() {
        const scrollTop = window.scrollY;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const progress = (scrollTop / docHeight) * 100;
        progressBar.style.width = progress + '%';
    }

    // === Navigation ===
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');

    function handleScroll() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        updateProgress();
    }

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
        document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
    });

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            document.body.style.overflow = '';
        });
    });

    // Smooth scroll with offset
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
            e.preventDefault();
            const target = document.querySelector(anchor.getAttribute('href'));
            if (target) {
                const offset = 80;
                const position = target.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top: position, behavior: 'smooth' });
            }
        });
    });

    // === Scroll Animations ===
    const animatedElements = document.querySelectorAll('[data-animate]');

    const scrollObserver = new IntersectionObserver(
        (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const delay = parseFloat(entry.target.dataset.delay || 0) * 1000;
                    setTimeout(() => {
                        entry.target.classList.add('visible');
                    }, delay);
                    scrollObserver.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.15, rootMargin: '0px 0px -50px 0px' }
    );

    animatedElements.forEach(el => scrollObserver.observe(el));

    // === Counter Animation ===
    const counters = document.querySelectorAll('[data-count]');

    const counterObserver = new IntersectionObserver(
        (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const target = parseInt(el.dataset.count);
                    const suffix = el.dataset.suffix || '';
                    const duration = 2000;
                    const start = performance.now();

                    function updateCounter(now) {
                        const elapsed = now - start;
                        const progress = Math.min(elapsed / duration, 1);
                        // Ease out cubic
                        const eased = 1 - Math.pow(1 - progress, 3);
                        const current = Math.round(eased * target);
                        el.textContent = current + suffix;

                        if (progress < 1) {
                            requestAnimationFrame(updateCounter);
                        }
                    }
                    requestAnimationFrame(updateCounter);
                    counterObserver.unobserve(el);
                }
            });
        },
        { threshold: 0.5 }
    );

    counters.forEach(el => counterObserver.observe(el));

    // === 3D Tilt Effect ===
    const tiltCards = document.querySelectorAll('.tilt-card');

    if (window.innerWidth > 768) {
        tiltCards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                const rotateX = ((y - centerY) / centerY) * -6;
                const rotateY = ((x - centerX) / centerX) * 6;

                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0px)';
                card.style.transition = 'transform 0.5s ease';
                setTimeout(() => { card.style.transition = ''; }, 500);
            });

            card.addEventListener('mouseenter', () => {
                card.style.transition = 'none';
            });
        });
    }

    // === Magnetic Buttons ===
    const magneticElements = document.querySelectorAll('.magnetic');

    if (window.innerWidth > 768) {
        magneticElements.forEach(el => {
            el.addEventListener('mousemove', (e) => {
                const rect = el.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                el.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px)`;
            });

            el.addEventListener('mouseleave', () => {
                el.style.transform = 'translate(0px, 0px)';
                el.style.transition = 'transform 0.4s ease';
                setTimeout(() => { el.style.transition = ''; }, 400);
            });

            el.addEventListener('mouseenter', () => {
                el.style.transition = 'none';
            });
        });
    }

    // === Parallax on Hero Orbs ===
    const orbs = document.querySelectorAll('.hero-orb');

    if (window.innerWidth > 768) {
        window.addEventListener('mousemove', (e) => {
            const x = (e.clientX / window.innerWidth - 0.5) * 2;
            const y = (e.clientY / window.innerHeight - 0.5) * 2;

            orbs.forEach((orb, i) => {
                const speed = (i + 1) * 15;
                orb.style.transform = `translate(${x * speed}px, ${y * speed}px)`;
            });
        });
    }

    // === Hero Animations ===
    function initHeroAnimations() {
        const heroElements = document.querySelectorAll('[data-animate="hero"], [data-animate="split-text"]');
        heroElements.forEach(el => {
            const delay = parseFloat(el.dataset.delay || 0) * 1000;
            setTimeout(() => {
                el.classList.add('visible');
            }, delay);
        });

        // Animate hero children
        const heroContent = document.querySelector('.hero-content');
        if (heroContent) {
            const children = heroContent.querySelectorAll('[data-animate]');
            children.forEach(child => {
                const delay = parseFloat(child.dataset.delay || 0) * 1000;
                setTimeout(() => {
                    child.classList.add('visible');
                }, delay);
            });
        }
    }

    // === Active Nav on Scroll ===
    const sections = document.querySelectorAll('section[id]');

    function highlightNav() {
        const scrollPos = window.scrollY + 120;
        sections.forEach(section => {
            const top = section.offsetTop;
            const height = section.offsetHeight;
            const id = section.getAttribute('id');
            if (scrollPos >= top && scrollPos < top + height) {
                navLinks.forEach(link => {
                    if (link.getAttribute('href') === `#${id}`) {
                        link.style.color = 'var(--color-primary)';
                    } else if (!link.classList.contains('nav-cta')) {
                        link.style.color = '';
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', highlightNav, { passive: true });

    // === RGPD Cookie Consent ===
    const cookieBanner = document.getElementById('cookieBanner');
    const cookieAccept = document.getElementById('cookieAccept');
    const cookieReject = document.getElementById('cookieReject');
    const mapPlaceholder = document.getElementById('mapPlaceholder');
    const googleMap = document.getElementById('googleMap');
    const loadMapBtn = document.getElementById('loadMap');
    const privacyModal = document.getElementById('privacyModal');
    const closePrivacy = document.getElementById('closePrivacy');
    const openPrivacyBtn = document.getElementById('openPrivacy');
    const openCookiesBtn = document.getElementById('openCookies');
    const cookiePrivacyLink = document.getElementById('cookiePrivacyLink');

    function getConsent() {
        return localStorage.getItem('cookieConsent');
    }

    function setConsent(value) {
        localStorage.setItem('cookieConsent', value);
    }

    function loadGoogleMap() {
        if (googleMap && googleMap.dataset.src) {
            googleMap.src = googleMap.dataset.src;
            googleMap.style.display = 'block';
            if (mapPlaceholder) mapPlaceholder.style.display = 'none';
        }
    }

    function showMapPlaceholder() {
        if (mapPlaceholder) mapPlaceholder.style.display = 'flex';
        if (googleMap) googleMap.style.display = 'none';
    }

    function hideBanner() {
        cookieBanner.classList.remove('visible');
    }

    // Check consent on load
    const consent = getConsent();
    if (consent === null) {
        // No choice made yet - show banner after a short delay
        setTimeout(() => {
            cookieBanner.classList.add('visible');
        }, 1500);
    } else if (consent === 'accepted') {
        loadGoogleMap();
    } else {
        showMapPlaceholder();
    }

    // Accept cookies
    cookieAccept.addEventListener('click', () => {
        setConsent('accepted');
        hideBanner();
        loadGoogleMap();
    });

    // Reject cookies
    cookieReject.addEventListener('click', () => {
        setConsent('rejected');
        hideBanner();
        showMapPlaceholder();
    });

    // Load map button (on placeholder)
    if (loadMapBtn) {
        loadMapBtn.addEventListener('click', () => {
            setConsent('accepted');
            loadGoogleMap();
        });
    }

    // Privacy modal
    function openPrivacyModal(e) {
        if (e) e.preventDefault();
        privacyModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closePrivacyModal() {
        privacyModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (openPrivacyBtn) openPrivacyBtn.addEventListener('click', openPrivacyModal);
    if (openCookiesBtn) {
        openCookiesBtn.addEventListener('click', (e) => {
            e.preventDefault();
            // Reset consent and show banner again
            localStorage.removeItem('cookieConsent');
            showMapPlaceholder();
            cookieBanner.classList.add('visible');
        });
    }
    if (cookiePrivacyLink) cookiePrivacyLink.addEventListener('click', openPrivacyModal);
    if (closePrivacy) closePrivacy.addEventListener('click', closePrivacyModal);

    // Close modal on overlay click
    privacyModal.addEventListener('click', (e) => {
        if (e.target === privacyModal) closePrivacyModal();
    });

    // Close modal on Escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && privacyModal.classList.contains('active')) {
            closePrivacyModal();
        }
    });
});
